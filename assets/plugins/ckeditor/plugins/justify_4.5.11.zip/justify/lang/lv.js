/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'lv', {
	block: 'Izlīdzināt malas',
	center: 'Izlīdzināt pret centru',
	left: 'Izlīdzināt pa kreisi',
	right: 'Izlīdzināt pa labi'
} );
